# Code Repository for "Julia Programming for Operations Research"

<!-- [![Build Status](https://travis-ci.org/chkwon/jpor_codes.svg?branch=master)](https://travis-ci.org/chkwon/jpor_codes) -->

<a href="https://www.chkwon.net/julia/"><img src="https://www.chkwon.net/julia/book/cover.png" width=300 border=1></a>

[Lear more about the book](http://www.chkwon.net/julia/)

Currently tested with:
- Julia v1.3.0
- JuMP v0.21.2
- Optim v0.20.6
